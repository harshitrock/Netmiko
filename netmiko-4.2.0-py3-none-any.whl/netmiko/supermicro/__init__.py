from netmiko.supermicro.smci_smis import SmciSwitchSmisTelnet, SmciSwitchSmisSSH

__all__ = ["SmciSwitchSmisSSH", "SmciSwitchSmisTelnet"]
