from netmiko.teldat.teldat_cit import TeldatCITSSH, TeldatCITTelnet

__all__ = ["TeldatCITSSH", "TeldatCITTelnet"]
