from netmiko.zte.zte_zxros import ZteZxrosSSH
from netmiko.zte.zte_zxros import ZteZxrosTelnet

__all__ = ["ZteZxrosSSH", "ZteZxrosTelnet"]
