from netmiko.linux.linux_ssh import LinuxSSH


class OvsLinuxSSH(LinuxSSH):
    pass
